"""
Generate realistic sample sales data for the dashboard.

Outputs (in ../sample_data/):
  - sales_data.csv
  - sales_data.xlsx
  - sales.db          (SQLite database with a `sales` table)

Usage:
    python scripts/generate_sample_data.py
"""
import csv
import random
import sqlite3
from datetime import date, timedelta
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "sample_data"
OUT.mkdir(exist_ok=True)

random.seed(42)

# product, category, unit price, unit cost, popularity weight
PRODUCTS = [
    ("Aero Laptop 14", "Electronics", 74999, 58000, 5),
    ("Pulse Smartphone X", "Electronics", 42999, 33000, 9),
    ("Nova Noise-Cancel Headphones", "Electronics", 12999, 7800, 8),
    ("Orbit Smartwatch", "Electronics", 15999, 10200, 6),
    ("Breeze Air Purifier", "Home & Kitchen", 11499, 7000, 5),
    ("ChefPro Mixer Grinder", "Home & Kitchen", 4299, 2600, 8),
    ("Brew Master Coffee Maker", "Home & Kitchen", 6999, 4100, 4),
    ("Cozy Cotton Bedsheet Set", "Home & Kitchen", 1899, 900, 9),
    ("Urban Runner Shoes", "Fashion", 3499, 1700, 10),
    ("Classic Denim Jacket", "Fashion", 2799, 1300, 6),
    ("Everyday Backpack", "Fashion", 1599, 700, 9),
    ("Silk Festive Kurta", "Fashion", 2399, 1100, 5),
    ("Yoga Mat Pro", "Sports & Fitness", 999, 420, 8),
    ("Adjustable Dumbbell Set", "Sports & Fitness", 5499, 3200, 4),
    ("Trail Cycling Helmet", "Sports & Fitness", 2199, 1100, 5),
    ("Whey Protein 2kg", "Sports & Fitness", 3299, 2100, 7),
    ("Glow Vitamin C Serum", "Beauty", 799, 280, 9),
    ("Herbal Hair Oil Pack", "Beauty", 449, 160, 10),
    ("Matte Lipstick Collection", "Beauty", 1299, 520, 6),
]

# region, weight, city list
REGIONS = [
    ("North", 28, ["Delhi", "Lucknow", "Chandigarh", "Jaipur"]),
    ("South", 26, ["Bengaluru", "Chennai", "Hyderabad", "Kochi"]),
    ("West", 30, ["Mumbai", "Pune", "Ahmedabad", "Surat"]),
    ("East", 16, ["Kolkata", "Patna", "Bhubaneswar", "Guwahati"]),
]
SEGMENTS = [("Consumer", 62), ("Corporate", 24), ("Small Business", 14)]
CHANNELS = [("Online", 58), ("Retail Store", 30), ("Marketplace", 12)]

# month-of-year seasonality (festive Oct-Nov peak, small Jan dip)
SEASON = {1: 0.85, 2: 0.9, 3: 1.0, 4: 0.95, 5: 1.0, 6: 0.92,
          7: 0.95, 8: 1.05, 9: 1.1, 10: 1.35, 11: 1.45, 12: 1.2}

START = date(2024, 1, 1)
END = date(2025, 12, 31)


def wchoice(items, weights):
    return random.choices(items, weights=weights, k=1)[0]


rows = []
order_no = 10000
day = START
while day <= END:
    year_growth = 1 + 0.18 * ((day - START).days / 365)  # ~18% growth per year
    weekend = 1.15 if day.weekday() >= 5 else 1.0
    n_orders = int(random.gauss(5.5, 1.5) * SEASON[day.month] * year_growth * weekend)
    for _ in range(max(n_orders, 1)):
        order_no += 1
        prod = wchoice(PRODUCTS, [p[4] for p in PRODUCTS])
        name, cat, price, cost, _w = prod
        region = wchoice(REGIONS, [r[1] for r in REGIONS])
        city = random.choice(region[2])
        segment = wchoice([s[0] for s in SEGMENTS], [s[1] for s in SEGMENTS])
        channel = wchoice([c[0] for c in CHANNELS], [c[1] for c in CHANNELS])
        qty = wchoice([1, 2, 3, 4, 5], [60, 22, 10, 5, 3])
        if price > 20000:
            qty = 1 if random.random() < 0.9 else 2
        discount = wchoice([0, 0.05, 0.1, 0.15, 0.2], [55, 15, 15, 10, 5])
        unit_price = round(price * (1 - discount))
        revenue = unit_price * qty
        profit = round((unit_price - cost) * qty)
        rows.append({
            "Order ID": f"ORD-{order_no}",
            "Order Date": day.isoformat(),
            "Product": name,
            "Category": cat,
            "Region": region[0],
            "City": city,
            "Customer Segment": segment,
            "Sales Channel": channel,
            "Quantity": qty,
            "Unit Price": unit_price,
            "Discount %": int(discount * 100),
            "Revenue": revenue,
            "Profit": profit,
        })
    day += timedelta(days=1)

fields = list(rows[0].keys())

# CSV
with open(OUT / "sales_data.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    w.writerows(rows)

# Excel
try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "Sales"
    ws.append(fields)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="14213D")
    for r in rows:
        ws.append([r[k] for k in fields])
    ws.freeze_panes = "A2"
    for i, k in enumerate(fields, start=1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = max(12, len(k) + 4)
    wb.save(OUT / "sales_data.xlsx")
except ImportError:
    print("openpyxl not installed - skipped Excel output (pip install openpyxl)")

# SQLite
db_path = OUT / "sales.db"
if db_path.exists():
    db_path.unlink()
con = sqlite3.connect(db_path)
con.execute("""
CREATE TABLE sales (
    order_id TEXT, order_date TEXT, product TEXT, category TEXT, region TEXT,
    city TEXT, customer_segment TEXT, sales_channel TEXT, quantity INTEGER,
    unit_price REAL, discount_pct INTEGER, revenue REAL, profit REAL
)""")
con.executemany(
    "INSERT INTO sales VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
    [tuple(r[k] for k in fields) for r in rows],
)
con.commit()
con.close()

print(f"Generated {len(rows):,} orders -> {OUT}")
