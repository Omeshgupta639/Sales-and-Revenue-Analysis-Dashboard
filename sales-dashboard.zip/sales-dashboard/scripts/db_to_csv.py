"""
Export sales data from a database into a CSV the dashboard can load.

SQLite (no extra packages needed):
    python scripts/db_to_csv.py --db sample_data/sales.db --table sales --out my_export.csv

Any other database (MySQL, PostgreSQL, SQL Server ...) via SQLAlchemy:
    pip install sqlalchemy pandas pymysql          # or psycopg2-binary, pyodbc
    python scripts/db_to_csv.py \
        --url "mysql+pymysql://user:password@localhost/shop" \
        --query "SELECT * FROM orders WHERE order_date >= '2024-01-01'" \
        --out my_export.csv

Then open index.html and drop my_export.csv onto the page.
"""
import argparse
import csv
import sqlite3
import sys


def export_sqlite(path, query, out):
    con = sqlite3.connect(path)
    cur = con.execute(query)
    headers = [d[0] for d in cur.description]
    n = 0
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(headers)
        for row in cur:
            w.writerow(row)
            n += 1
    con.close()
    return n


def export_sqlalchemy(url, query, out):
    try:
        import pandas as pd
        from sqlalchemy import create_engine
    except ImportError:
        sys.exit("Install dependencies first: pip install sqlalchemy pandas <your-db-driver>")
    engine = create_engine(url)
    df = pd.read_sql(query, engine)
    df.to_csv(out, index=False)
    return len(df)


def main():
    p = argparse.ArgumentParser(description="Export database rows to CSV for the sales dashboard.")
    p.add_argument("--db", help="Path to a SQLite database file")
    p.add_argument("--url", help="SQLAlchemy URL for other databases")
    p.add_argument("--table", default="sales", help="Table name (used when --query is not given)")
    p.add_argument("--query", help="Custom SQL query (overrides --table)")
    p.add_argument("--out", default="sales_export.csv", help="Output CSV path")
    a = p.parse_args()

    query = a.query or f"SELECT * FROM {a.table}"
    if a.db:
        n = export_sqlite(a.db, query, a.out)
    elif a.url:
        n = export_sqlalchemy(a.url, query, a.out)
    else:
        p.error("Provide --db (SQLite file) or --url (SQLAlchemy URL)")
    print(f"Exported {n:,} rows -> {a.out}")


if __name__ == "__main__":
    main()
