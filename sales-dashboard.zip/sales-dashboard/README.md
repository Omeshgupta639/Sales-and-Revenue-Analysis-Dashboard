# Sales & Revenue Analysis Dashboard

An interactive dashboard for exploring sales and revenue data. Import an Excel or CSV file, track KPIs, and drill into the numbers with filters, slicers, and clickable charts. It runs entirely in the browser, so there is nothing to install and your data never leaves your computer.

**Live demo:** after you publish with GitHub Pages (steps below), it will be at `https://<your-username>.github.io/<repo-name>/`

## What it does

| Requirement | How it is covered |
|---|---|
| Import data from Excel, CSV, or a database | Drag and drop `.xlsx`, `.xls`, `.csv`, `.tsv` files. For databases, `scripts/db_to_csv.py` exports any SQLite, MySQL, PostgreSQL or SQL Server table or query to a CSV. |
| Visualize KPIs | Total revenue, orders, units sold, average order value, profit and profit margin, each with a change versus the previous period. |
| Revenue trends | Line chart by day, week or month, with an optional "compare with last year" line. |
| Top-performing products | Top 10 bar chart (switch between revenue, units, profit) plus a sortable product table with revenue share and margin. |
| Charts, filters, slicers | Date range and quick presets, one-click slicers for category, region, customer segment and sales channel, product search, and click-to-filter on charts. |
| Business insights | An automatic "What the data says" panel: best seller, strongest month, 3-month momentum, fastest-growing category, regional split, margins, busiest weekday. |

Other details: dark mode, currency switcher (INR, USD, EUR, GBP), export of the filtered rows to CSV, a column-mapping dialog for files with unusual headings, and a layout that works on phones.

## Quick start

1. Download or clone this repository.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox, Safari). An internet connection is needed once per page load because Chart.js and the Excel reader load from a CDN.
3. Click **Load sample data** to see it working, or **Import file** to use your own data.

No build step, no server, no dependencies.

## Your data format

One row per order line (or per order). The dashboard detects columns by name, so these all work: `Order Date`, `Date`, `Product`, `Item`, `Category`, `Region`, `Revenue`, `Sales`, `Amount`, `Quantity`, `Unit Price`, `Profit`, `Cost`.

| Column | Required? | Notes |
|---|---|---|
| Date | Yes | `2025-03-14`, `14/03/2025`, `14 Mar 2025`, or real Excel dates. A date like `03/04/2025` is read as day first. |
| Product | Yes | |
| Revenue | Yes* | *Or provide both Quantity and Unit price and revenue is calculated. |
| Category, Region, Customer Segment, Sales Channel | No | Each one that exists becomes a slicer. |
| Order ID | No | Used to count unique orders. Without it, each row counts as one order. |
| Quantity | No | Enables the Units KPI. |
| Profit (or Total cost) | No | Enables Profit and Margin KPIs. |

If a heading is not recognized, a dialog lets you match columns by hand. Rows with a missing date or revenue are skipped and the count is shown. For Excel files, the first sheet that contains data is read. Numbers may include currency symbols and thousands separators; European decimal commas are not supported.

## Importing from a database

The browser cannot connect to a database directly, so export first, then drop the CSV into the dashboard.

```bash
# SQLite (no extra packages)
python scripts/db_to_csv.py --db sample_data/sales.db --table sales --out export.csv

# MySQL / PostgreSQL / SQL Server (via SQLAlchemy)
pip install sqlalchemy pandas pymysql
python scripts/db_to_csv.py \
  --url "mysql+pymysql://user:password@localhost/shop" \
  --query "SELECT order_date, product, category, region, quantity, revenue FROM orders" \
  --out export.csv
```

## Project structure

```
sales-dashboard/
├── index.html                      # The whole dashboard (HTML, CSS, JavaScript)
├── sample_data/
│   ├── sales_data.csv              # 4,944 sample orders, 2024-2025
│   ├── sales_data.xlsx             # Same data as an Excel workbook
│   └── sales.db                    # Same data in a SQLite database
├── scripts/
│   ├── generate_sample_data.py     # Recreates the sample files
│   └── db_to_csv.py                # Database to CSV exporter
├── requirements.txt                # Only needed for the optional Python scripts
├── LICENSE
└── README.md
```

## Upload to GitHub

**Option A: Git command line**

```bash
cd sales-dashboard
git init
git add .
git commit -m "Add sales and revenue dashboard"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
Create the empty repository on github.com first (no README or license, since this project has them).

**Option B: Browser only**

1. On github.com, click **New repository**, name it, and create it.
2. Click **uploading an existing file**, drag in the contents of the unzipped folder (keep the `sample_data` and `scripts` folders), and click **Commit changes**.

**Publish it as a live website (GitHub Pages)**

1. In the repository, open **Settings > Pages**.
2. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, and save.
3. After a minute or two the dashboard is live at `https://<your-username>.github.io/<repo-name>/`.

## How the numbers are calculated

- **Total revenue**: sum of the revenue column for the rows that match the current filters.
- **Orders**: unique Order IDs (or row count if there is no Order ID column).
- **Average order value**: revenue divided by orders.
- **Profit margin**: profit divided by revenue.
- **Change versus previous period**: when a date range is selected, it is compared with the equal-length period just before it. With no date filter, the latest month is compared with the month before it, and the label names both months. If the latest month is incomplete, that comparison understates it.
- **Weekday chart**: total revenue per weekday divided by the number of distinct days on which that weekday had sales.
- **Momentum insights**: the last 3 months compared with the 3 months before, which needs at least 6 months of data.

## Customizing

- **Colours and fonts**: edit the CSS variables at the top of `index.html` (`--accent`, `--c1` to `--c8`, `--head`, `--body`).
- **New slicer**: add an entry to `FIELDS` and `DIMS` in the script, and a matching property in `normalizeRows`.
- **Working offline**: download `chart.umd.min.js` (Chart.js 4.4.1) and `xlsx.full.min.js` (SheetJS 0.18.5) next to `index.html` and change the two `<script src>` lines to point at them. CSV import works even without the Excel reader.

## Learning notes

This project practices: cleaning and normalizing messy input (dates, currency strings, inconsistent headings), aggregating data (group by, time-series bucketing, period-over-period comparison), choosing the right chart for each question, cross-filtering design, and turning numbers into plain-language findings.

## Tech

Vanilla JavaScript, [Chart.js](https://www.chartjs.org/) 4.4.1 for charts, [SheetJS](https://sheetjs.com/) 0.18.5 for Excel files. Optional Python 3 scripts use only the standard library (plus `openpyxl` to write the sample Excel file).

## License

MIT. See `LICENSE`.
